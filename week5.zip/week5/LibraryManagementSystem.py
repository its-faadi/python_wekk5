# .............. This is the code without optional points ...................


# Book Class
class Book:
    def __init__(self, title, author, isbn):
        # Initialize the book with title, author, ISBN, and set status to checked in
        self.title = title
        self.author = author
        self.isbn = isbn
        self.status = "checked in"  # Initial status is checked in

    def check_out(self):
        # Mark the book as checked out
        if self.status == "checked out":
            raise Exception(f"The book '{self.title}' is already checked out.")
        self.status = "checked out"

    def check_in(self):
        # Mark the book as checked in
        self.status = "checked in"

# Library Class
class Library:
    def __init__(self):
        # Initialize an empty list to store books
        self.books = []

    def add_book(self, book):
        # Add a book to the library collection
        self.books.append(book)

    def remove_book(self, isbn):
        # Remove a book from the collection by ISBN
        self.books = [book for book in self.books if book.isbn != isbn]

    def find_book_by_isbn(self, isbn):
        # Find a book in the collection by ISBN
        for book in self.books:
            if book.isbn == isbn:
                return book
        return None

    def display_all_books(self):
        # Display all books in the library
        for book in self.books:
            print(f"{book.title} by {book.author} (ISBN: {book.isbn}) - {book.status}")

    def display_available_books(self):
        # Display only the books that are available (checked in)
        for book in self.books:
            if book.status == "checked in":
                print(f"{book.title} by {book.author} (ISBN: {book.isbn})")

# Command-line Interface (CLI)
def main():
    # Initialize the library
    library = Library()

    while True:
        # Display the menu options
        print("\nLibrary Management System")
        print("1. Display all books")
        print("2. Display available books")
        print("3. Add a new book")
        print("4. Remove a book")
        print("5. Borrow a book")
        print("6. Return a book")
        print("7. Exit")

        # Get the user's choice
        choice = input("Enter your choice: ")

        if choice == "1":
            # Display all books in the library
            library.display_all_books()
        elif choice == "2":
            # Display only the available books
            library.display_available_books()
        elif choice == "3":
            # Add a new book to the library
            title = input("Enter the book title: ")
            author = input("Enter the author: ")
            isbn = input("Enter the ISBN: ")
            new_book = Book(title, author, isbn)
            library.add_book(new_book)
            print(f"Book '{title}' added to the library.")
        elif choice == "4":
            # Remove a book from the library by ISBN
            isbn = input("Enter the ISBN of the book to remove: ")
            library.remove_book(isbn)
            print(f"Book with ISBN {isbn} removed from the library.")
        elif choice == "5":
            # Borrow a book by ISBN (check it out)
            isbn = input("Enter the ISBN of the book you want to borrow: ")
            book = library.find_book_by_isbn(isbn)
            if book:
                try:
                    book.check_out()
                    print(f"You have successfully borrowed '{book.title}'.")
                except Exception as e:
                    print(e)
            else:
                print("Book not found.")
        elif choice == "6":
            # Return a book by ISBN (check it in)
            isbn = input("Enter the ISBN of the book you want to return: ")
            book = library.find_book_by_isbn(isbn)
            if book:
                book.check_in()
                print(f"You have successfully returned '{book.title}'.")
            else:
                print("Book not found.")
        elif choice == "7":
            # Exit the program
            print("Exiting the program...")
            break
        else:
            # Handle invalid input
            print("Invalid choice. Please try again.")

# Entry point of the program
if __name__ == "__main__":
    main()
